from django.contrib import admin

from .models import Consultation, DrugInteraction


@admin.register(DrugInteraction)
class DrugInteractionAdmin(admin.ModelAdmin):
    list_display = ["ingredient_a", "ingredient_b", "severity", "effect", "is_published", "reviewed_by", "updated_at"]
    list_filter = ["severity", "is_published"]
    search_fields = ["ingredient_a", "ingredient_b", "effect"]

    def save_model(self, request, obj, form, change):
        obj.reviewed_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(Consultation)
class ConsultationAdmin(admin.ModelAdmin):
    list_display = ["created_at", "name", "phone", "topic", "status", "answered_by"]
    list_filter = ["status", "topic"]
    search_fields = ["name", "phone", "question", "medicines"]
