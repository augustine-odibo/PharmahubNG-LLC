from django.conf import settings
from django.db import models


class DrugInteraction(models.Model):
    """A known interaction between two active ingredients.

    Entries should be added and reviewed by a licensed pharmacist using a
    recognised reference (e.g. BNF, Stockley's, Lexicomp, the product SmPC).
    """

    class Severity(models.TextChoices):
        MAJOR = "major", "Major - avoid combination"
        MODERATE = "moderate", "Moderate - use with caution / monitor"
        MINOR = "minor", "Minor"

    ingredient_a = models.CharField(max_length=120, help_text="Lower-case generic name")
    ingredient_b = models.CharField(max_length=120, help_text="Lower-case generic name")
    severity = models.CharField(max_length=20, choices=Severity.choices)
    effect = models.CharField(max_length=255, help_text="What can happen, in plain language")
    advice = models.TextField(help_text="What the patient should do")
    reference = models.CharField(max_length=255, blank=True, help_text="Source used")
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    is_published = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["ingredient_a", "ingredient_b"]
        constraints = [
            models.UniqueConstraint(fields=["ingredient_a", "ingredient_b"], name="unique_interaction_pair"),
        ]

    def save(self, *args, **kwargs):
        # Store pairs in a canonical order so (a,b) and (b,a) are the same row
        a, b = sorted([self.ingredient_a.strip().lower(), self.ingredient_b.strip().lower()])
        self.ingredient_a, self.ingredient_b = a, b
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.ingredient_a} + {self.ingredient_b} ({self.severity})"


class Consultation(models.Model):
    """Ask-a-pharmacist: free drug and poison information requests."""

    class Topic(models.TextChoices):
        DRUG_INFO = "drug_info", "Drug information"
        SIDE_EFFECT = "side_effect", "Side effect / reaction"
        POISON = "poison", "Poisoning / overdose"
        DOSING = "dosing", "How to take my medicine"
        OTHER = "other", "Other"

    class Status(models.TextChoices):
        OPEN = "open", "Open"
        ANSWERED = "answered", "Answered"
        CLOSED = "closed", "Closed"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="consultations")
    name = models.CharField(max_length=150)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    topic = models.CharField(max_length=20, choices=Topic.choices, default=Topic.DRUG_INFO)
    medicines = models.CharField(max_length=255, blank=True, help_text="Medicines involved")
    patient_age = models.CharField(max_length=30, blank=True)
    question = models.TextField()

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN)
    response = models.TextField(blank=True)
    answered_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="answered_consultations")
    answered_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.get_topic_display()} · {self.name}"

    @property
    def is_urgent(self):
        return self.topic == self.Topic.POISON
