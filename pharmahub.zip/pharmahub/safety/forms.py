from django import forms

from .models import Consultation


class ConsultationForm(forms.ModelForm):
    class Meta:
        model = Consultation
        fields = ["name", "phone", "email", "topic", "medicines", "patient_age", "question"]
        widgets = {"question": forms.Textarea(attrs={"rows": 4})}


class AnswerForm(forms.ModelForm):
    class Meta:
        model = Consultation
        fields = ["response", "status"]
        widgets = {"response": forms.Textarea(attrs={"rows": 5})}
