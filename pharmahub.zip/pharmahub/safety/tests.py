from django.test import TestCase
from django.urls import reverse

from .models import Consultation, DrugInteraction
from .services import check_interactions


class InteractionTests(TestCase):
    def setUp(self):
        DrugInteraction.objects.create(ingredient_a="Warfarin", ingredient_b="aspirin", severity="major",
                                       effect="Bleeding risk.", advice="Avoid.")
        DrugInteraction.objects.create(ingredient_a="x", ingredient_b="y", severity="minor",
                                       effect="Hidden", advice="-", is_published=False)

    def test_pairs_are_order_independent(self):
        self.assertEqual(len(check_interactions(["aspirin", "warfarin"])), 1)
        self.assertEqual(len(check_interactions(["WARFARIN ", "Aspirin", "paracetamol"])), 1)

    def test_unpublished_rules_hidden(self):
        self.assertEqual(check_interactions(["x", "y"]), [])

    def test_checker_page_and_api(self):
        r = self.client.get(reverse("safety:checker"), {"drugs": "warfarin, aspirin"})
        self.assertContains(r, "Bleeding risk.")
        data = self.client.get(reverse("api_interactions"), {"drugs": "warfarin,aspirin"}).json()
        self.assertEqual(data["interactions"][0]["severity"], "major")


class ConsultationTests(TestCase):
    def test_anyone_can_ask(self):
        r = self.client.post(reverse("safety:consult"), {
            "name": "Bayo", "phone": "0801", "topic": "poison", "question": "Child swallowed tablets",
        })
        self.assertEqual(r.status_code, 302)
        self.assertTrue(Consultation.objects.get().is_urgent)
