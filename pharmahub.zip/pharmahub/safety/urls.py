from django.urls import path

from . import views

app_name = "safety"
urlpatterns = [
    path("interaction-checker/", views.interaction_checker, name="checker"),
    path("ask-a-pharmacist/", views.consult, name="consult"),
    path("consultations/<int:pk>/answer/", views.answer, name="answer"),
]
