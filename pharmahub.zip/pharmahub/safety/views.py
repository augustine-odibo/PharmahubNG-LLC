from django.contrib import messages
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from catalog.models import Product
from core.permissions import pharmacist_required

from .forms import AnswerForm, ConsultationForm
from .models import Consultation
from .services import check_interactions, normalise


def _collect(request):
    """Ingredients from free text (?drugs=a,b) and/or product ids (?product=1&product=2)."""
    names = normalise(request.GET.getlist("drugs") + [request.GET.get("q", "")])
    products = list(Product.objects.active().filter(pk__in=[p for p in request.GET.getlist("product") if p.isdigit()]))
    for p in products:
        for ing in p.ingredients:
            if ing not in names:
                names.append(ing)
    return names, products


def interaction_checker(request):
    names, products = _collect(request)
    results = check_interactions(names) if len(names) >= 2 else None
    return render(request, "safety/checker.html", {
        "names": names, "products": products, "results": results,
        "all_products": Product.objects.active().exclude(generic_name="").only("pk", "name", "generic_name"),
    })


def api_interactions(request):
    """GET /api/interactions/?drugs=warfarin,aspirin"""
    names, _ = _collect(request)
    return JsonResponse({
        "checked": names,
        "interactions": [
            {"a": i.ingredient_a, "b": i.ingredient_b, "severity": i.severity, "effect": i.effect, "advice": i.advice}
            for i in check_interactions(names)
        ],
        "disclaimer": "No result does not mean a combination is safe. Ask a pharmacist.",
    })


def consult(request):
    initial = {}
    if request.user.is_authenticated:
        initial = {"name": request.user.get_full_name(), "phone": request.user.phone, "email": request.user.email}
    form = ConsultationForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        c = form.save(commit=False)
        if request.user.is_authenticated:
            c.user = request.user
        c.save()
        messages.success(request, "Thanks! A licensed pharmacist will respond by phone or WhatsApp as soon as possible.")
        return redirect("safety:consult")
    return render(request, "safety/consult.html", {"form": form})


@pharmacist_required
def answer(request, pk):
    c = get_object_or_404(Consultation, pk=pk)
    form = AnswerForm(request.POST or None, instance=c, initial={"status": Consultation.Status.ANSWERED})
    if request.method == "POST" and form.is_valid():
        c = form.save(commit=False)
        c.answered_by, c.answered_at = request.user, timezone.now()
        c.save()
        messages.success(request, "Response saved.")
        return redirect("core:staff_dashboard")
    return render(request, "safety/answer.html", {"c": c, "form": form})
