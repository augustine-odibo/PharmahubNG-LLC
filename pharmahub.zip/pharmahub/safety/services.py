from itertools import combinations

from django.db.models import Q

from .models import DrugInteraction

SEVERITY_ORDER = {"major": 0, "moderate": 1, "minor": 2}


def normalise(names):
    out = []
    for n in names:
        for part in str(n).split(","):
            p = part.strip().lower()
            if p and p not in out:
                out.append(p)
    return out


def check_interactions(ingredients):
    """Return published interactions between any pair of the given ingredients,
    most severe first."""
    ings = normalise(ingredients)
    if len(ings) < 2:
        return []
    q = Q()
    for a, b in combinations(ings, 2):
        x, y = sorted([a, b])
        q |= Q(ingredient_a=x, ingredient_b=y)
    found = DrugInteraction.objects.filter(q, is_published=True)
    return sorted(found, key=lambda i: SEVERITY_ORDER.get(i.severity, 9))


def check_products(products):
    ingredients = []
    for p in products:
        ingredients.extend(p.ingredients)
    return check_interactions(ingredients)
