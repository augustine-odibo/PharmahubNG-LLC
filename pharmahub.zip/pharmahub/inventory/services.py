"""Inventory logic: FEFO allocation, restocking, expiry and reorder forecasting."""
import math
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from .models import Batch, StockMovement


class InsufficientStock(Exception):
    def __init__(self, product, requested, available):
        self.product, self.requested, self.available = product, requested, available
        super().__init__(f"Only {available} of {product} available (requested {requested}).")


@transaction.atomic
def allocate_stock(product, quantity, reference="", user=None):
    """Remove `quantity` units of `product`, taking from the batch that expires
    soonest first (FEFO). Expired batches are never used.

    Returns a list of (batch, qty) tuples. Raises InsufficientStock.
    """
    today = timezone.localdate()
    batches = list(
        Batch.objects.select_for_update()
        .filter(product=product, expiry_date__gt=today, quantity__gt=0)
        .order_by("expiry_date", "received_at")
    )
    available = sum(b.quantity for b in batches)
    if available < quantity:
        raise InsufficientStock(product, quantity, available)

    remaining, taken = quantity, []
    for batch in batches:
        if remaining == 0:
            break
        use = min(batch.quantity, remaining)
        batch.quantity -= use
        batch.save(update_fields=["quantity"])
        StockMovement.objects.create(
            product=product, batch=batch, change=-use,
            reason=StockMovement.Reason.SOLD, reference=reference, created_by=user,
        )
        taken.append((batch, use))
        remaining -= use
    return taken


@transaction.atomic
def return_stock(product, allocations, reference="", user=None):
    """Put stock back into the batches it came from (e.g. order cancelled)."""
    for batch_id, qty in allocations:
        batch = Batch.objects.select_for_update().get(pk=batch_id)
        batch.quantity += qty
        batch.save(update_fields=["quantity"])
        StockMovement.objects.create(
            product=product, batch=batch, change=qty,
            reason=StockMovement.Reason.RETURNED, reference=reference, created_by=user,
        )


def expiring_batches(days=None):
    days = days or settings.PHARMAHUB["EXPIRY_WARNING_DAYS"]
    today = timezone.localdate()
    return (
        Batch.objects.select_related("product", "supplier")
        .filter(quantity__gt=0, expiry_date__gt=today, expiry_date__lte=today + timedelta(days=days))
        .order_by("expiry_date")
    )


def expired_batches():
    return (
        Batch.objects.select_related("product")
        .filter(quantity__gt=0, expiry_date__lte=timezone.localdate())
        .order_by("expiry_date")
    )


def average_daily_sales(product, days=30):
    since = timezone.now() - timedelta(days=days)
    sold = (
        StockMovement.objects.filter(product=product, reason=StockMovement.Reason.SOLD, created_at__gte=since)
        .aggregate(t=Sum("change"))["t"] or 0
    )
    returned = (
        StockMovement.objects.filter(product=product, reason=StockMovement.Reason.RETURNED, created_at__gte=since)
        .aggregate(t=Sum("change"))["t"] or 0
    )
    return max(0, (-sold) - returned) / days


def reorder_suggestion(product, lead_time_days=None, safety_days=7, cover_days=30):
    """Demand-based reorder suggestion.

    reorder point = daily demand x (lead time + safety days)
    order quantity = enough to cover `cover_days` beyond the reorder point.
    Falls back to the product's manual reorder level when there's no sales history.
    """
    lead = lead_time_days or settings.PHARMAHUB["SUPPLIER_LEAD_TIME_DAYS"]
    daily = average_daily_sales(product)
    stock = product.stock
    reorder_point = max(product.reorder_level, math.ceil(daily * (lead + safety_days)))
    days_left = math.floor(stock / daily) if daily else None
    suggested = 0
    if stock <= reorder_point:
        target = reorder_point + math.ceil(daily * cover_days) if daily else product.reorder_level * 2
        suggested = max(0, target - stock)
    return {
        "product": product,
        "stock": stock,
        "daily_demand": round(daily, 2),
        "days_of_stock": days_left,
        "reorder_point": reorder_point,
        "suggested_qty": suggested,
    }


def reorder_report(products):
    rows = [reorder_suggestion(p) for p in products]
    return sorted([r for r in rows if r["suggested_qty"] > 0], key=lambda r: (r["days_of_stock"] is None, r["days_of_stock"] or 0))
