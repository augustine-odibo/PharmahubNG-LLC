from django import forms
from django.utils import timezone

from .models import Batch, ProcurementRequest


class ReceiveStockForm(forms.ModelForm):
    class Meta:
        model = Batch
        fields = ["product", "supplier", "batch_number", "manufacture_date", "expiry_date", "quantity", "cost_price"]
        widgets = {
            "manufacture_date": forms.DateInput(attrs={"type": "date"}),
            "expiry_date": forms.DateInput(attrs={"type": "date"}),
        }

    def clean_expiry_date(self):
        d = self.cleaned_data["expiry_date"]
        if d <= timezone.localdate():
            raise forms.ValidationError("This batch is already expired. Do not receive it into stock.")
        return d

    def clean_quantity(self):
        q = self.cleaned_data["quantity"]
        if q <= 0:
            raise forms.ValidationError("Quantity must be at least 1.")
        return q


class ProcurementForm(forms.ModelForm):
    class Meta:
        model = ProcurementRequest
        fields = ["business_name", "pcn_premises_number", "contact_phone", "delivery_address", "items", "needed_by", "notes"]
        widgets = {
            "items": forms.Textarea(attrs={"rows": 6, "placeholder": "Amoxicillin 500 mg capsules – 20 packs\nORS sachets – 200\nSurgical gloves (M) – 10 boxes"}),
            "delivery_address": forms.Textarea(attrs={"rows": 2}),
            "notes": forms.Textarea(attrs={"rows": 2}),
            "needed_by": forms.DateInput(attrs={"type": "date"}),
        }
