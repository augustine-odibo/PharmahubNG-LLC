from django.contrib import admin

from .models import Batch, ProcurementRequest, StockMovement, Supplier


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ["name", "phone", "email", "cac_number", "pcn_premises_number", "is_verified", "lead_time_days"]
    list_filter = ["is_verified"]
    search_fields = ["name", "cac_number", "pcn_premises_number"]


@admin.register(Batch)
class BatchAdmin(admin.ModelAdmin):
    list_display = ["product", "batch_number", "supplier", "expiry_date", "quantity", "is_expired"]
    list_filter = ["supplier", "expiry_date"]
    search_fields = ["product__name", "batch_number"]
    date_hierarchy = "expiry_date"
    autocomplete_fields = ["product"]

    @admin.display(boolean=True)
    def is_expired(self, obj):
        return obj.is_expired


@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ["created_at", "product", "batch", "change", "reason", "reference", "created_by"]
    list_filter = ["reason"]
    search_fields = ["product__name", "reference"]
    readonly_fields = [f.name for f in StockMovement._meta.fields]

    def has_add_permission(self, request):
        return False  # movements are created by the system so the audit trail stays honest


@admin.register(ProcurementRequest)
class ProcurementAdmin(admin.ModelAdmin):
    list_display = ["id", "business_name", "requester", "status", "needed_by", "quote_amount", "created_at"]
    list_filter = ["status"]
    list_editable = ["status"]
    search_fields = ["business_name", "items"]
