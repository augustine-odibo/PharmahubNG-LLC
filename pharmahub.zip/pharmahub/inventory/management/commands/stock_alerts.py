"""Daily stock report: low stock, reorder suggestions and expiring batches.

Run every morning (cron, Render Cron Job, etc.):

    python manage.py stock_alerts --email ops@pharmahub.com.ng
"""
from django.conf import settings
from django.core.mail import send_mail
from django.core.management.base import BaseCommand

from catalog.models import Product
from inventory.services import expired_batches, expiring_batches, reorder_report


class Command(BaseCommand):
    help = "Print (and optionally email) low-stock, reorder and expiry alerts."

    def add_arguments(self, parser):
        parser.add_argument("--email", action="append", default=[], help="Recipient (repeatable)")

    def handle(self, *args, **opts):
        lines = ["PharmaHub daily stock report", ""]
        reorder = reorder_report(Product.objects.active())
        lines.append(f"REORDER NOW ({len(reorder)})")
        for r in reorder:
            days = f"{r['days_of_stock']} days left" if r["days_of_stock"] is not None else "no recent sales"
            lines.append(f"  - {r['product']}: {r['stock']} in stock ({days}) → order {r['suggested_qty']}")
        exp = list(expired_batches())
        lines += ["", f"EXPIRED – REMOVE FROM SHELF ({len(exp)})"]
        lines += [f"  - {b.product} batch {b.batch_number}: {b.quantity} units, expired {b.expiry_date}" for b in exp]
        soon = list(expiring_batches())
        lines += ["", f"EXPIRING WITHIN {settings.PHARMAHUB['EXPIRY_WARNING_DAYS']} DAYS ({len(soon)})"]
        lines += [f"  - {b.product} batch {b.batch_number}: {b.quantity} units, expires {b.expiry_date} ({b.days_to_expiry} days)" for b in soon]
        report = "\n".join(lines)
        self.stdout.write(report)
        if opts["email"]:
            send_mail("PharmaHub stock report", report, settings.DEFAULT_FROM_EMAIL, opts["email"])
            self.stdout.write(self.style.SUCCESS(f"Emailed to {', '.join(opts['email'])}"))
