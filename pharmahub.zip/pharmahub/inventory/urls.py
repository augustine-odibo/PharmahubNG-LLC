from django.urls import path

from . import views

app_name = "inventory"
urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("receive/", views.receive_stock, name="receive"),
    path("procurement/", views.procurement_request, name="procurement"),
]
