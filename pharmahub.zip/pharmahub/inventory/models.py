from django.conf import settings
from django.db import models
from django.utils import timezone

from catalog.models import Product


class Supplier(models.Model):
    name = models.CharField(max_length=150)
    contact_person = models.CharField(max_length=120, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    cac_number = models.CharField("CAC RC number", max_length=50, blank=True)
    pcn_premises_number = models.CharField("PCN premises licence", max_length=50, blank=True)
    is_verified = models.BooleanField(
        default=False, help_text="Tick only after checking CAC and PCN registration documents."
    )
    lead_time_days = models.PositiveIntegerField(default=14)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="supplier_profile", help_text="Supplier's login, if they manage their own catalogue.",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name + (" ✓" if self.is_verified else "")


class Batch(models.Model):
    """A delivery of one product with one batch number and expiry date.

    Stock is tracked per batch so we can sell first-expiry-first-out (FEFO)
    and never sell expired medicine.
    """
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="batches")
    supplier = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True, related_name="batches")
    batch_number = models.CharField(max_length=60)
    manufacture_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField()
    quantity = models.PositiveIntegerField(default=0)
    cost_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    received_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["expiry_date"]
        verbose_name_plural = "batches"
        constraints = [
            models.UniqueConstraint(fields=["product", "batch_number"], name="unique_batch_per_product"),
        ]

    def __str__(self):
        return f"{self.product} · {self.batch_number} (exp {self.expiry_date:%b %Y})"

    @property
    def is_expired(self):
        return self.expiry_date <= timezone.localdate()

    @property
    def days_to_expiry(self):
        return (self.expiry_date - timezone.localdate()).days


class StockMovement(models.Model):
    class Reason(models.TextChoices):
        RECEIVED = "received", "Received from supplier"
        SOLD = "sold", "Sold"
        RETURNED = "returned", "Returned / order cancelled"
        EXPIRED = "expired", "Expired - removed"
        DAMAGED = "damaged", "Damaged"
        ADJUSTMENT = "adjustment", "Stock count adjustment"

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="movements")
    batch = models.ForeignKey(Batch, on_delete=models.SET_NULL, null=True, blank=True, related_name="movements")
    change = models.IntegerField(help_text="Positive adds stock, negative removes it.")
    reason = models.CharField(max_length=20, choices=Reason.choices)
    reference = models.CharField(max_length=60, blank=True, help_text="Order number, invoice, etc.")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.change:+} {self.product} ({self.get_reason_display()})"


class ProcurementRequest(models.Model):
    """B2B: a pharmacy or hospital asks PharmaHub to source medicines in bulk."""

    class Status(models.TextChoices):
        NEW = "new", "New"
        SOURCING = "sourcing", "Sourcing from suppliers"
        QUOTED = "quoted", "Quote sent"
        ACCEPTED = "accepted", "Accepted"
        FULFILLED = "fulfilled", "Fulfilled"
        DECLINED = "declined", "Declined"

    requester = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="procurement_requests")
    business_name = models.CharField(max_length=150)
    pcn_premises_number = models.CharField(max_length=50, blank=True)
    contact_phone = models.CharField(max_length=20)
    delivery_address = models.TextField()
    items = models.TextField(help_text="One item per line: product, strength, quantity")
    needed_by = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NEW)
    quote_amount = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)
    staff_notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Procurement #{self.pk} · {self.business_name}"
