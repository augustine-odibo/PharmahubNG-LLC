from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from catalog.models import Product
from core.permissions import pharmacist_required

from .forms import ProcurementForm, ReceiveStockForm
from .models import StockMovement, Supplier
from .services import expired_batches, expiring_batches, reorder_report


@pharmacist_required
def dashboard(request):
    products = Product.objects.active().prefetch_related("batches")
    stock_rows = sorted(
        ({"product": p, "stock": p.stock, "low": p.low_stock} for p in products),
        key=lambda r: r["stock"],
    )
    return render(request, "inventory/dashboard.html", {
        "stock_rows": stock_rows,
        "expiring": expiring_batches(),
        "expired": expired_batches(),
        "reorder": reorder_report(products),
        "movements": StockMovement.objects.select_related("product", "batch")[:25],
        "suppliers": Supplier.objects.all(),
    })


@pharmacist_required
def receive_stock(request):
    form = ReceiveStockForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        batch = form.save()
        StockMovement.objects.create(
            product=batch.product, batch=batch, change=batch.quantity,
            reason=StockMovement.Reason.RECEIVED, reference=batch.batch_number, created_by=request.user,
        )
        messages.success(request, f"Received {batch.quantity} × {batch.product} (batch {batch.batch_number}).")
        return redirect("inventory:dashboard")
    return render(request, "inventory/receive.html", {"form": form})


@login_required
def procurement_request(request):
    u = request.user
    form = ProcurementForm(request.POST or None, initial={
        "business_name": u.business_name, "pcn_premises_number": u.pcn_premises_number,
        "contact_phone": u.phone, "delivery_address": u.address,
    })
    if request.method == "POST" and form.is_valid():
        pr = form.save(commit=False)
        pr.requester = u
        pr.save()
        messages.success(request, f"Request #{pr.pk} sent. Our procurement team will send you a quote.")
        return redirect("accounts:dashboard")
    return render(request, "inventory/procurement.html", {"form": form})
