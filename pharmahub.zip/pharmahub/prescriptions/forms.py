from django import forms

from .models import ALLOWED_EXTENSIONS, Prescription


class PrescriptionForm(forms.ModelForm):
    class Meta:
        model = Prescription
        fields = ["file", "patient_name", "prescriber_name", "hospital", "issue_date", "notes"]
        widgets = {
            "issue_date": forms.DateInput(attrs={"type": "date"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
            "file": forms.ClearableFileInput(attrs={"accept": ",".join(sorted(ALLOWED_EXTENSIONS))}),
        }


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Prescription
        fields = ["status", "pharmacist_notes", "valid_until"]
        widgets = {
            "valid_until": forms.DateInput(attrs={"type": "date"}),
            "pharmacist_notes": forms.Textarea(attrs={"rows": 3}),
        }

    def clean_status(self):
        status = self.cleaned_data["status"]
        if status == Prescription.Status.PENDING:
            raise forms.ValidationError("Choose Approve or Reject.")
        return status
