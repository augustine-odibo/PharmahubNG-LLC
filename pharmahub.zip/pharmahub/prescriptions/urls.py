from django.urls import path

from . import views

app_name = "prescriptions"
urlpatterns = [
    path("", views.my_prescriptions, name="list"),
    path("upload/", views.upload, name="upload"),
    path("<int:pk>/file/", views.view_file, name="file"),
    path("<int:pk>/review/", views.review, name="review"),
]
