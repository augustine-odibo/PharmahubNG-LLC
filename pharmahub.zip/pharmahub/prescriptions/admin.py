from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from .models import Prescription


@admin.register(Prescription)
class PrescriptionAdmin(admin.ModelAdmin):
    list_display = ["id", "patient_name", "patient", "status", "reviewed_by", "created_at", "file_link"]
    list_filter = ["status"]
    search_fields = ["patient_name", "patient__username", "prescriber_name", "hospital"]
    readonly_fields = ["file_link", "reviewed_by", "reviewed_at", "created_at"]
    exclude = ["file"]

    @admin.display(description="File")
    def file_link(self, obj):
        if not obj.pk:
            return "-"
        return format_html('<a href="{}" target="_blank">View prescription</a>', reverse("prescriptions:file", args=[obj.pk]))
