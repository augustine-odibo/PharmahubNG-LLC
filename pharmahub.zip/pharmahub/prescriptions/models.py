import os
import uuid
from pathlib import Path

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.storage import FileSystemStorage
from django.db import models
from django.utils.deconstruct import deconstructible


@deconstructible
class PrivateStorage(FileSystemStorage):
    """Prescriptions live outside MEDIA_ROOT and are never given a public URL.
    The location is read from settings at use time, so no machine-specific
    path ends up in migrations."""

    def __init__(self):
        super().__init__(base_url=None)

    @property
    def base_location(self):
        return settings.PRIVATE_MEDIA_ROOT

    @property
    def location(self):
        return os.path.abspath(self.base_location)


private_storage = PrivateStorage()

ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".webp", ".heic"}
MAX_UPLOAD_MB = 5


def validate_prescription_file(f):
    ext = Path(f.name).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValidationError("Upload a PDF or a photo (JPG, PNG, WEBP, HEIC).")
    if f.size > MAX_UPLOAD_MB * 1024 * 1024:
        raise ValidationError(f"File is too large. The maximum is {MAX_UPLOAD_MB} MB.")


def prescription_path(instance, filename):
    ext = Path(filename).suffix.lower()
    return f"prescriptions/{instance.patient_id}/{uuid.uuid4().hex}{ext}"


class Prescription(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Awaiting pharmacist review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"

    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="prescriptions")
    file = models.FileField(upload_to=prescription_path, storage=private_storage, validators=[validate_prescription_file])
    patient_name = models.CharField(max_length=150, help_text="Name written on the prescription")
    prescriber_name = models.CharField(max_length=150, blank=True)
    hospital = models.CharField(max_length=150, blank=True)
    issue_date = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True, help_text="Anything the pharmacist should know (allergies, other medicines)")

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="reviewed_prescriptions"
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    pharmacist_notes = models.TextField(blank=True)
    valid_until = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Rx #{self.pk} · {self.patient_name} ({self.get_status_display()})"

    @property
    def is_usable(self):
        from django.utils import timezone
        if self.status != self.Status.APPROVED:
            return False
        return self.valid_until is None or self.valid_until >= timezone.localdate()
