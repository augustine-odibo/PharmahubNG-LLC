import mimetypes

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.permissions import pharmacist_required
from core.utils import safe_next
from orders.models import Order
from orders.services import set_status

from .forms import PrescriptionForm, ReviewForm
from .models import Prescription


@login_required
def upload(request):
    form = PrescriptionForm(request.POST or None, request.FILES or None,
                            initial={"patient_name": request.user.get_full_name()})
    if request.method == "POST" and form.is_valid():
        rx = form.save(commit=False)
        rx.patient = request.user
        rx.save()
        messages.success(request, "Prescription uploaded. A licensed pharmacist will review it shortly.")
        return redirect(safe_next(request, request.GET.get("next"), "prescriptions:list"))
    return render(request, "prescriptions/upload.html", {"form": form})


@login_required
def my_prescriptions(request):
    return render(request, "prescriptions/list.html", {"prescriptions": request.user.prescriptions.all()})


@login_required
def view_file(request, pk):
    """Stream a prescription file to its owner or a pharmacist only."""
    rx = get_object_or_404(Prescription, pk=pk)
    if rx.patient_id != request.user.pk and not request.user.is_pharmacist:
        raise PermissionDenied
    try:
        fh = rx.file.open("rb")
    except FileNotFoundError:
        raise Http404("File missing")
    ctype = mimetypes.guess_type(rx.file.name)[0] or "application/octet-stream"
    resp = FileResponse(fh, content_type=ctype)
    resp["Content-Disposition"] = "inline"
    resp["Cache-Control"] = "private, no-store"
    resp["X-Content-Type-Options"] = "nosniff"
    return resp


@pharmacist_required
def review(request, pk):
    rx = get_object_or_404(Prescription.objects.select_related("patient"), pk=pk)
    form = ReviewForm(request.POST or None, instance=rx)
    if request.method == "POST" and form.is_valid():
        rx = form.save(commit=False)
        rx.reviewed_by = request.user
        rx.reviewed_at = timezone.now()
        rx.save()
        # Move any orders waiting on this prescription
        for order in rx.orders.filter(status=Order.Status.AWAITING_RX):
            if rx.status == Prescription.Status.APPROVED:
                set_status(order, Order.Status.PENDING, "Prescription approved by pharmacist.", request.user)
            else:
                set_status(order, Order.Status.CANCELLED,
                           f"Prescription not approved: {rx.pharmacist_notes or 'please contact us'}", request.user)
        messages.success(request, f"Prescription #{rx.pk} marked {rx.get_status_display().lower()}.")
        return redirect("core:staff_dashboard")
    return render(request, "prescriptions/review.html", {"rx": rx, "form": form})
