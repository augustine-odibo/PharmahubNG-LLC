from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Q, Sum
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=110, unique=True, blank=True)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "categories"

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class ProductQuerySet(models.QuerySet):
    def active(self):
        return self.filter(is_active=True)

    def search(self, q):
        if not q:
            return self
        return self.filter(
            Q(name__icontains=q) | Q(generic_name__icontains=q)
            | Q(brand__icontains=q) | Q(description__icontains=q)
        )


class Product(models.Model):
    class Schedule(models.TextChoices):
        OTC = "otc", "Over the counter (OTC)"
        POM = "pom", "Prescription-only (POM)"
        CONSUMABLE = "consumable", "Medical consumable / device"

    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name="products")
    generic_name = models.CharField(
        max_length=200, blank=True,
        help_text="Active ingredient(s), comma separated. Used by the interaction checker.",
    )
    brand = models.CharField(max_length=120, blank=True)
    strength = models.CharField(max_length=80, blank=True, help_text="e.g. 500 mg, 2 mg/5 ml")
    dosage_form = models.CharField(max_length=80, blank=True, help_text="e.g. tablet, syrup, eye drop")
    pack_size = models.CharField(max_length=80, blank=True)
    nafdac_number = models.CharField("NAFDAC reg. no.", max_length=50, blank=True)
    schedule = models.CharField(max_length=20, choices=Schedule.choices, default=Schedule.OTC)

    description = models.TextField(blank=True)
    usage_info = models.TextField("How to use", blank=True)
    warnings = models.TextField(blank=True)
    storage = models.CharField(max_length=200, blank=True)

    price = models.DecimalField(max_digits=12, decimal_places=2)
    sale_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    bulk_price = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        help_text="Unit price for verified pharmacies buying at or above the bulk quantity.",
    )
    bulk_min_qty = models.PositiveIntegerField(default=10)

    image = models.ImageField(upload_to="products/", blank=True)
    image_url = models.URLField(blank=True, help_text="Used when no image is uploaded.")

    reorder_level = models.PositiveIntegerField(default=10)
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ProductQuerySet.as_manager()

    class Meta:
        ordering = ["name"]

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.name)[:200] or "product"
            slug, n = base, 2
            while Product.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug, n = f"{base}-{n}", n + 1
            self.slug = slug
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("catalog:product_detail", args=[self.slug])

    # ---- pricing ----
    @property
    def current_price(self) -> Decimal:
        if self.sale_price is not None and self.sale_price < self.price:
            return self.sale_price
        return self.price

    @property
    def on_sale(self):
        return self.current_price < self.price

    @property
    def discount_percent(self):
        if not self.on_sale or not self.price:
            return 0
        return round((1 - self.current_price / self.price) * 100)

    def unit_price_for(self, user, quantity):
        """Verified B2B buyers get bulk pricing when they meet the minimum quantity."""
        if (
            self.bulk_price is not None
            and quantity >= self.bulk_min_qty
            and getattr(user, "is_authenticated", False)
            and getattr(user, "is_b2b", False)
            and user.pcn_premises_number
        ):
            return min(self.bulk_price, self.current_price)
        return self.current_price

    # ---- regulation ----
    @property
    def requires_prescription(self):
        return self.schedule == self.Schedule.POM

    @property
    def ingredients(self):
        return [i.strip().lower() for i in self.generic_name.split(",") if i.strip()]

    # ---- media ----
    @property
    def image_src(self):
        if self.image:
            return self.image.url
        return self.image_url or f"{settings.STATIC_URL}img/placeholder.svg"

    # ---- stock (sellable = in-date batches only) ----
    @property
    def stock(self):
        today = timezone.localdate()
        total = self.batches.filter(expiry_date__gt=today).aggregate(t=Sum("quantity"))["t"]
        return total or 0

    @property
    def in_stock(self):
        return self.stock > 0

    @property
    def low_stock(self):
        return self.stock <= self.reorder_level
