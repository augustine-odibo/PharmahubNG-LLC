from django.contrib import admin

from inventory.models import Batch

from .models import Category, Product


class BatchInline(admin.TabularInline):
    model = Batch
    extra = 0
    fields = ["batch_number", "supplier", "expiry_date", "quantity", "cost_price"]


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ["name", "slug"]
    prepopulated_fields = {"slug": ["name"]}


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ["name", "generic_name", "strength", "schedule", "price", "sale_price", "stock_display", "is_active", "is_featured"]
    list_filter = ["schedule", "category", "is_active", "is_featured"]
    list_editable = ["price", "sale_price", "is_active", "is_featured"]
    search_fields = ["name", "generic_name", "brand", "nafdac_number"]
    prepopulated_fields = {"slug": ["name"]}
    inlines = [BatchInline]
    fieldsets = (
        (None, {"fields": ("name", "slug", "category", "brand", "is_active", "is_featured")}),
        ("Clinical", {"fields": ("generic_name", "strength", "dosage_form", "pack_size", "schedule", "nafdac_number")}),
        ("Content", {"fields": ("description", "usage_info", "warnings", "storage", "image", "image_url")}),
        ("Pricing", {"fields": ("price", "sale_price", "bulk_price", "bulk_min_qty")}),
        ("Inventory", {"fields": ("reorder_level",)}),
    )

    @admin.display(description="In stock")
    def stock_display(self, obj):
        s = obj.stock
        return f"{s} ⚠" if s <= obj.reorder_level else s
