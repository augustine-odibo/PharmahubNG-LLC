from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render

from .models import Category, Product

SORTS = {
    "name": "name",
    "price_low": "price",
    "price_high": "-price",
    "newest": "-created_at",
}


def product_list(request):
    qs = Product.objects.active().select_related("category").prefetch_related("batches")
    q = request.GET.get("q", "").strip()
    cat = request.GET.get("category", "")
    schedule = request.GET.get("type", "")
    sort = request.GET.get("sort", "name")

    qs = qs.search(q)
    category = None
    if cat:
        category = Category.objects.filter(slug=cat).first()
        if category:
            qs = qs.filter(category=category)
    if schedule in Product.Schedule.values:
        qs = qs.filter(schedule=schedule)
    qs = qs.order_by(SORTS.get(sort, "name"))

    page = Paginator(qs, 12).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    return render(request, "catalog/product_list.html", {
        "page": page, "q": q, "category": category, "categories": Category.objects.all(),
        "schedule": schedule, "schedules": Product.Schedule.choices, "sort": sort,
        "querystring": params.urlencode(),
    })


def product_detail(request, slug):
    product = get_object_or_404(Product.objects.active().select_related("category"), slug=slug)
    related = (
        Product.objects.active().filter(category=product.category).exclude(pk=product.pk)[:4]
        if product.category else []
    )
    return render(request, "catalog/product_detail.html", {"product": product, "related": related})


def api_products(request):
    """GET /api/products/?q=para  – lightweight JSON for search-as-you-type and future mobile apps."""
    qs = Product.objects.active().search(request.GET.get("q", "").strip())[:20]
    return JsonResponse({"results": [
        {
            "id": p.pk, "name": p.name, "slug": p.slug, "generic_name": p.generic_name,
            "strength": p.strength, "price": str(p.current_price), "was": str(p.price) if p.on_sale else None,
            "prescription_required": p.requires_prescription, "in_stock": p.in_stock,
            "image": request.build_absolute_uri(p.image_src) if p.image_src.startswith("/") else p.image_src,
            "url": request.build_absolute_uri(p.get_absolute_url()),
        } for p in qs
    ]})
