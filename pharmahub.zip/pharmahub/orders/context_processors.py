from .cart import SESSION_KEY


def cart(request):
    data = request.session.get(SESSION_KEY, {}) if hasattr(request, "session") else {}
    return {"cart_count": sum(data.values())}
