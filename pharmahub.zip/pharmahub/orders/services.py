import json

from django.db import transaction

from inventory.services import InsufficientStock, allocate_stock, return_stock
from safety.services import check_products

from .models import DeliveryUpdate, Order, OrderItem


class CheckoutError(Exception):
    pass


@transaction.atomic
def place_order(cart, user, details, prescription=None):
    """Turn the cart into an order, reserving stock FEFO. All-or-nothing."""
    lines = cart.lines()
    if not lines:
        raise CheckoutError("Your cart is empty.")

    needs_rx = any(line["product"].requires_prescription for line in lines)
    if needs_rx:
        if prescription is None:
            raise CheckoutError("Your cart has prescription-only medicines. Please upload or choose a prescription.")
        if prescription.patient_id != user.pk:
            raise CheckoutError("That prescription doesn't belong to your account.")
        if prescription.status == prescription.Status.REJECTED:
            raise CheckoutError("That prescription was not approved. Please upload a new one.")

    fulfilment = details.get("fulfilment", Order.Fulfilment.DELIVERY)
    order = Order.objects.create(
        customer=user,
        status=Order.Status.AWAITING_RX if (needs_rx and not prescription.is_usable) else Order.Status.PENDING,
        fulfilment=fulfilment,
        full_name=details["full_name"],
        phone=details["phone"],
        email=details.get("email", ""),
        address=details.get("address", ""),
        city=details.get("city", ""),
        state=details.get("state", ""),
        notes=details.get("notes", ""),
        prescription=prescription if needs_rx else None,
        delivery_fee=cart.delivery_fee(fulfilment),
    )

    for line in lines:
        product = line["product"]
        try:
            taken = allocate_stock(product, line["quantity"], reference=order.number, user=user)
        except InsufficientStock as e:
            raise CheckoutError(
                f"Sorry, only {e.available} of “{product.name}” left in stock. Please update your cart."
            ) from e
        OrderItem.objects.create(
            order=order, product=product, product_name=product.name,
            unit_price=line["unit_price"], quantity=line["quantity"],
            allocations=json.dumps([[b.pk, q] for b, q in taken]),
        )

    warnings = check_products([line["product"] for line in lines])
    order.interaction_warnings = "\n".join(
        f"[{w.get_severity_display()}] {w.ingredient_a} + {w.ingredient_b}: {w.effect}" for w in warnings
    )
    order.recalc()
    order.save()
    DeliveryUpdate.objects.create(
        order=order, status=order.status,
        message="Order received. A pharmacist will check your prescription."
        if order.status == Order.Status.AWAITING_RX else "Order received. We'll confirm shortly.",
    )
    cart.clear()
    return order


@transaction.atomic
def set_status(order, status, message="", user=None):
    if order.status == Order.Status.CANCELLED:
        raise CheckoutError("This order is already cancelled.")
    if status == Order.Status.CANCELLED:
        for item in order.items.all():
            return_stock(item.product, item.get_allocations(), reference=order.number, user=user)
            item.allocations = "[]"
            item.save(update_fields=["allocations"])
    order.status = status
    order.save(update_fields=["status", "updated_at"])
    return DeliveryUpdate.objects.create(order=order, status=status, message=message, created_by=user)
