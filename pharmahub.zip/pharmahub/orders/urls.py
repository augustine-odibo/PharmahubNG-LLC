from django.urls import path

from . import views

app_name = "orders"
urlpatterns = [
    path("cart/", views.cart_detail, name="cart"),
    path("cart/add/<int:pk>/", views.cart_add, name="cart_add"),
    path("cart/update/<int:pk>/", views.cart_update, name="cart_update"),
    path("cart/remove/<int:pk>/", views.cart_remove, name="cart_remove"),
    path("checkout/", views.checkout, name="checkout"),
    path("orders/", views.order_list, name="list"),
    path("orders/<str:number>/", views.order_detail, name="detail"),
    path("orders/<str:number>/cancel/", views.order_cancel, name="cancel"),
    path("orders/<str:number>/update/", views.order_update, name="update"),
]
