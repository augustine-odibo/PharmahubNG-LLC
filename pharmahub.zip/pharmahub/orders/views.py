from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from catalog.models import Product
from core.permissions import pharmacist_required
from core.utils import safe_next
from safety.services import check_products

from .cart import Cart
from .forms import CheckoutForm, StatusForm
from .models import Order
from .services import CheckoutError, place_order, set_status


def _wants_json(request):
    return request.headers.get("x-requested-with") == "XMLHttpRequest" or "application/json" in request.headers.get("accept", "")


def cart_detail(request):
    cart = Cart(request)
    lines = cart.lines()
    products = [line["product"] for line in lines]
    return render(request, "orders/cart.html", {
        "cart": cart, "lines": lines, "subtotal": cart.subtotal, "delivery_fee": cart.delivery_fee(),
        "total": cart.subtotal + cart.delivery_fee(),
        "interactions": check_products(products), "needs_rx": cart.needs_prescription,
    })


@require_POST
def cart_add(request, pk):
    product = get_object_or_404(Product.objects.active(), pk=pk)
    cart = Cart(request)
    try:
        qty = max(1, int(request.POST.get("quantity", 1)))
    except ValueError:
        qty = 1
    in_cart = cart.data.get(str(product.pk), 0)
    if in_cart + qty > product.stock:
        msg = f"Sorry, only {product.stock} of {product.name} in stock."
        if _wants_json(request):
            return JsonResponse({"ok": False, "message": msg, "count": len(cart)}, status=400)
        messages.error(request, msg)
        return redirect(safe_next(request, request.POST.get("next"), product.get_absolute_url()))
    cart.add(product, qty)
    msg = f"{product.name} added to cart."
    if _wants_json(request):
        return JsonResponse({"ok": True, "message": msg, "count": len(cart)})
    messages.success(request, msg)
    return redirect(safe_next(request, request.POST.get("next"), "orders:cart"))


@require_POST
def cart_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    cart = Cart(request)
    try:
        qty = int(request.POST.get("quantity", 0))
    except ValueError:
        qty = 0
    if qty > product.stock:
        messages.error(request, f"Only {product.stock} of {product.name} in stock.")
        qty = product.stock
    cart.add(product, qty, replace=True)
    return redirect("orders:cart")


@require_POST
def cart_remove(request, pk):
    Cart(request).remove(get_object_or_404(Product, pk=pk))
    return redirect("orders:cart")


@login_required
def checkout(request):
    cart = Cart(request)
    if not len(cart):
        messages.info(request, "Your cart is empty.")
        return redirect("catalog:product_list")
    user = request.user
    needs_rx = cart.needs_prescription
    initial = {
        "full_name": user.get_full_name(), "phone": user.phone, "email": user.email,
        "address": user.address, "city": user.city, "state": user.state,
    }
    form = CheckoutForm(request.POST or None, user=user, needs_rx=needs_rx, initial=initial)
    if request.method == "POST" and form.is_valid():
        data = form.cleaned_data
        try:
            order = place_order(cart, user, data, prescription=data.get("prescription"))
        except CheckoutError as e:
            messages.error(request, str(e))
        else:
            messages.success(request, f"Order {order.number} placed! Tap “Confirm on WhatsApp” to finish.")
            return redirect(order.get_absolute_url())
    lines = cart.lines()
    return render(request, "orders/checkout.html", {
        "form": form, "lines": lines, "subtotal": cart.subtotal, "delivery_fee": cart.delivery_fee(),
        "total": cart.subtotal + cart.delivery_fee(),
        "needs_rx": needs_rx, "interactions": check_products([line["product"] for line in lines]),
    })


def _get_order_for(request, number):
    order = get_object_or_404(Order.objects.prefetch_related("items", "updates"), number=number)
    if order.customer_id != request.user.pk and not request.user.is_pharmacist:
        raise PermissionDenied
    return order


@login_required
def order_detail(request, number):
    order = _get_order_for(request, number)
    ctx = {"order": order}
    if request.user.is_pharmacist:
        ctx["status_form"] = StatusForm(initial={
            "status": order.status, "rider_name": order.rider_name, "rider_phone": order.rider_phone,
        })
    return render(request, "orders/order_detail.html", ctx)


@login_required
def order_list(request):
    return render(request, "orders/order_list.html", {"orders": request.user.orders.prefetch_related("items")})


@login_required
@require_POST
def order_cancel(request, number):
    order = _get_order_for(request, number)
    if order.status not in (Order.Status.AWAITING_RX, Order.Status.PENDING):
        messages.error(request, "This order is already being prepared. Please contact us on WhatsApp to cancel.")
    else:
        set_status(order, Order.Status.CANCELLED, "Cancelled by customer.", request.user)
        messages.success(request, "Order cancelled.")
    return redirect(order.get_absolute_url())


@pharmacist_required
@require_POST
def order_update(request, number):
    order = get_object_or_404(Order, number=number)
    form = StatusForm(request.POST)
    if form.is_valid():
        d = form.cleaned_data
        order.rider_name, order.rider_phone = d["rider_name"], d["rider_phone"]
        order.save(update_fields=["rider_name", "rider_phone"])
        if d["status"] != order.status or d["message"]:
            try:
                set_status(order, d["status"], d["message"], request.user)
            except CheckoutError as e:
                messages.error(request, str(e))
                return redirect(order.get_absolute_url())
        messages.success(request, "Order updated.")
    return redirect(order.get_absolute_url())


@login_required
def api_track(request, number):
    """GET /api/orders/<number>/  – order status timeline as JSON."""
    order = _get_order_for(request, number)
    return JsonResponse({
        "number": order.number, "status": order.status, "status_label": order.get_status_display(),
        "total": str(order.total),
        "timeline": [
            {"status": u.status, "label": u.get_status_display(), "message": u.message, "at": u.created_at.isoformat()}
            for u in order.updates.all()
        ],
    })
