import json
import secrets
from decimal import Decimal
from urllib.parse import quote

from django.conf import settings
from django.db import models
from django.urls import reverse

from catalog.models import Product
from prescriptions.models import Prescription


def new_order_number():
    return "PH-" + secrets.token_hex(4).upper()


class Order(models.Model):
    class Status(models.TextChoices):
        AWAITING_RX = "awaiting_rx", "Awaiting prescription check"
        PENDING = "pending", "Order received"
        CONFIRMED = "confirmed", "Confirmed (payment agreed)"
        PACKED = "packed", "Packed"
        DISPATCHED = "dispatched", "Out for delivery"
        READY = "ready", "Ready for pickup"
        DELIVERED = "delivered", "Delivered"
        CANCELLED = "cancelled", "Cancelled"

    class Fulfilment(models.TextChoices):
        DELIVERY = "delivery", "Home / office delivery"
        PICKUP = "pickup", "Pickup"

    ACTIVE_STATUSES = [Status.AWAITING_RX, Status.PENDING, Status.CONFIRMED, Status.PACKED, Status.DISPATCHED, Status.READY]

    number = models.CharField(max_length=20, unique=True, default=new_order_number, editable=False)
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="orders")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    fulfilment = models.CharField(max_length=20, choices=Fulfilment.choices, default=Fulfilment.DELIVERY)

    full_name = models.CharField(max_length=150)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=80, blank=True)
    state = models.CharField(max_length=80, blank=True)
    notes = models.TextField(blank=True)

    prescription = models.ForeignKey(Prescription, on_delete=models.SET_NULL, null=True, blank=True, related_name="orders")
    subtotal = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    delivery_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    rider_name = models.CharField(max_length=120, blank=True)
    rider_phone = models.CharField(max_length=20, blank=True)
    interaction_warnings = models.TextField(blank=True, help_text="Interaction alerts found at checkout")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.number

    def get_absolute_url(self):
        return reverse("orders:detail", args=[self.number])

    @property
    def is_active(self):
        return self.status in self.ACTIVE_STATUSES

    @property
    def requires_prescription(self):
        return self.items.filter(product__schedule=Product.Schedule.POM).exists()

    def recalc(self):
        self.subtotal = sum((i.line_total for i in self.items.all()), Decimal("0"))
        self.total = self.subtotal + self.delivery_fee

    def whatsapp_url(self):
        lines = [f"• {i.product_name} x{i.quantity} = ₦{i.line_total:,.2f}" for i in self.items.all()]
        msg = (
            f"Hello PharmaHub, I just placed order {self.number}.\n"
            + "\n".join(lines)
            + f"\nTotal: ₦{self.total:,.2f}\nName: {self.full_name}\nPhone: {self.phone}"
        )
        return f"https://wa.me/{settings.PHARMAHUB['WHATSAPP_NUMBER']}?text={quote(msg)}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="order_items")
    product_name = models.CharField(max_length=200)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    quantity = models.PositiveIntegerField()
    allocations = models.TextField(default="[]", help_text="JSON list of [batch_id, qty] used (FEFO)")

    def __str__(self):
        return f"{self.quantity} × {self.product_name}"

    @property
    def line_total(self):
        return self.unit_price * self.quantity

    def get_allocations(self):
        try:
            return json.loads(self.allocations)
        except ValueError:
            return []


class DeliveryUpdate(models.Model):
    """Timeline entry shown to the customer on the order tracking page."""
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="updates")
    status = models.CharField(max_length=20, choices=Order.Status.choices)
    message = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"{self.order} → {self.get_status_display()}"
