from django import forms

from prescriptions.models import Prescription

from .models import Order

NIGERIAN_STATES = [
    "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno", "Cross River", "Delta",
    "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT", "Gombe", "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi",
    "Kogi", "Kwara", "Lagos", "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers", "Sokoto",
    "Taraba", "Yobe", "Zamfara",
]


class CheckoutForm(forms.Form):
    full_name = forms.CharField(max_length=150)
    phone = forms.CharField(max_length=20)
    email = forms.EmailField(required=False)
    fulfilment = forms.ChoiceField(choices=Order.Fulfilment.choices, widget=forms.RadioSelect,
                                   initial=Order.Fulfilment.DELIVERY)
    address = forms.CharField(widget=forms.Textarea(attrs={"rows": 2}), required=False)
    city = forms.CharField(max_length=80, required=False)
    state = forms.ChoiceField(choices=[("", "Select state")] + [(s, s) for s in NIGERIAN_STATES], required=False)
    notes = forms.CharField(widget=forms.Textarea(attrs={"rows": 2}), required=False,
                            label="Order notes (allergies, delivery instructions)")
    prescription = forms.ModelChoiceField(queryset=Prescription.objects.none(), required=False,
                                          empty_label="Choose an uploaded prescription")

    def __init__(self, *args, user=None, needs_rx=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.needs_rx = needs_rx
        if user is not None:
            self.fields["prescription"].queryset = user.prescriptions.exclude(status=Prescription.Status.REJECTED)
        if not needs_rx:
            del self.fields["prescription"]

    def clean(self):
        data = super().clean()
        if data.get("fulfilment") == Order.Fulfilment.DELIVERY:
            for f in ("address", "city", "state"):
                if not data.get(f):
                    self.add_error(f, "Required for delivery.")
        if self.needs_rx and not data.get("prescription"):
            self.add_error("prescription", "Your cart has prescription-only medicines. Choose or upload a prescription.")
        return data


class StatusForm(forms.Form):
    status = forms.ChoiceField(choices=Order.Status.choices)
    message = forms.CharField(max_length=255, required=False)
    rider_name = forms.CharField(max_length=120, required=False)
    rider_phone = forms.CharField(max_length=20, required=False)
