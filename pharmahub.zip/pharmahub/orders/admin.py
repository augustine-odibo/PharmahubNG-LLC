from django.contrib import admin

from .models import DeliveryUpdate, Order, OrderItem


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ["product", "product_name", "unit_price", "quantity", "allocations"]
    can_delete = False


class DeliveryUpdateInline(admin.TabularInline):
    model = DeliveryUpdate
    extra = 0
    readonly_fields = ["status", "message", "created_by", "created_at"]


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ["number", "full_name", "phone", "status", "fulfilment", "total", "created_at"]
    list_filter = ["status", "fulfilment", "state"]
    search_fields = ["number", "full_name", "phone", "email"]
    readonly_fields = ["number", "subtotal", "delivery_fee", "total", "interaction_warnings", "created_at", "updated_at"]
    inlines = [OrderItemInline, DeliveryUpdateInline]
    date_hierarchy = "created_at"
