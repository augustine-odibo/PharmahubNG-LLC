from datetime import timedelta
from decimal import Decimal

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from accounts.models import User
from catalog.models import Product
from inventory.models import Batch, StockMovement
from inventory.services import InsufficientStock, allocate_stock, reorder_suggestion
from prescriptions.models import Prescription

from .models import Order

TMP = "/tmp/pharmahub-test-private"


def make_product(name="Paracetamol", schedule="otc", price=1000, batches=((30, 5), (365, 10)), **kw):
    p = Product.objects.create(name=name, schedule=schedule, price=price, generic_name=kw.pop("generic", name.lower()), **kw)
    today = timezone.localdate()
    for i, (days, qty) in enumerate(batches):
        Batch.objects.create(product=p, batch_number=f"B{i}", expiry_date=today + timedelta(days=days), quantity=qty)
    return p


ADDRESS = {"full_name": "Ada Obi", "phone": "08030000000", "fulfilment": "delivery",
           "address": "1 Test Street", "city": "Wuse", "state": "FCT"}


class InventoryServiceTests(TestCase):
    def test_fefo_takes_soonest_expiry_first(self):
        p = make_product()
        taken = allocate_stock(p, 7)
        self.assertEqual([(b.batch_number, q) for b, q in taken], [("B0", 5), ("B1", 2)])
        self.assertEqual(p.stock, 8)

    def test_expired_batches_are_never_sold(self):
        p = make_product(batches=((-1, 50), (100, 3)))
        self.assertEqual(p.stock, 3)
        with self.assertRaises(InsufficientStock):
            allocate_stock(p, 4)

    def test_reorder_suggestion_uses_sales_velocity(self):
        p = make_product(batches=((365, 20),), reorder_level=5)
        StockMovement.objects.create(product=p, change=-60, reason=StockMovement.Reason.SOLD)  # 2/day over 30 days
        r = reorder_suggestion(p, lead_time_days=14, safety_days=7)
        self.assertEqual(r["daily_demand"], 2.0)
        self.assertEqual(r["reorder_point"], 42)
        self.assertEqual(r["days_of_stock"], 10)
        self.assertGreater(r["suggested_qty"], 0)


@override_settings(PRIVATE_MEDIA_ROOT=TMP)
class CheckoutTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("ada", password="pw-123456!", first_name="Ada")
        self.client.force_login(self.user)

    def add(self, product, qty=1):
        return self.client.post(reverse("orders:cart_add", args=[product.pk]), {"quantity": qty})

    def test_otc_checkout_reserves_stock_and_adds_delivery_fee(self):
        p = make_product(price=2000)
        self.add(p, 3)
        r = self.client.post(reverse("orders:checkout"), ADDRESS)
        order = Order.objects.get()
        self.assertRedirects(r, order.get_absolute_url())
        self.assertEqual(order.status, Order.Status.PENDING)
        self.assertEqual(order.subtotal, Decimal("6000"))
        self.assertEqual(order.delivery_fee, Decimal("2500"))
        self.assertEqual(order.total, Decimal("8500"))
        self.assertEqual(p.stock, 12)
        self.assertIn("wa.me/2348024640699", order.whatsapp_url())
        self.assertEqual(self.client.session.get("cart"), {})

    def test_pickup_is_free(self):
        p = make_product()
        self.add(p)
        self.client.post(reverse("orders:checkout"), {**ADDRESS, "fulfilment": "pickup", "address": "", "city": "", "state": ""})
        self.assertEqual(Order.objects.get().delivery_fee, 0)

    def test_cannot_add_more_than_stock(self):
        p = make_product(batches=((100, 2),))
        r = self.add(p, 5)
        self.assertEqual(self.client.session.get("cart", {}), {})
        self.assertEqual(r.status_code, 302)

    def test_prescription_only_needs_prescription(self):
        p = make_product("Amoxicillin", schedule="pom")
        self.add(p)
        r = self.client.post(reverse("orders:checkout"), ADDRESS)
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Choose or upload a prescription")
        self.assertFalse(Order.objects.exists())

    def test_unreviewed_prescription_holds_order_then_approval_releases_it(self):
        p = make_product("Amoxicillin", schedule="pom")
        rx = Prescription.objects.create(patient=self.user, patient_name="Ada Obi",
                                         file=SimpleUploadedFile("rx.pdf", b"%PDF-1.4 test"))
        self.add(p)
        self.client.post(reverse("orders:checkout"), {**ADDRESS, "prescription": rx.pk})
        order = Order.objects.get()
        self.assertEqual(order.status, Order.Status.AWAITING_RX)

        pharmacist = User.objects.create_user("pharm", password="pw-123456!", role=User.Role.PHARMACIST)
        self.client.force_login(pharmacist)
        self.client.post(reverse("prescriptions:review", args=[rx.pk]), {"status": "approved"})
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.PENDING)

    def test_rejected_prescription_cancels_order_and_returns_stock(self):
        p = make_product("Amoxicillin", schedule="pom")
        rx = Prescription.objects.create(patient=self.user, patient_name="Ada",
                                         file=SimpleUploadedFile("rx.pdf", b"%PDF-1.4 test"))
        self.add(p, 2)
        self.client.post(reverse("orders:checkout"), {**ADDRESS, "prescription": rx.pk})
        self.assertEqual(p.stock, 13)
        pharmacist = User.objects.create_user("pharm", password="pw-123456!", role=User.Role.PHARMACIST)
        self.client.force_login(pharmacist)
        self.client.post(reverse("prescriptions:review", args=[rx.pk]), {"status": "rejected", "pharmacist_notes": "Illegible"})
        self.assertEqual(Order.objects.get().status, Order.Status.CANCELLED)
        self.assertEqual(p.stock, 15)

    def test_customer_cancel_returns_stock(self):
        p = make_product()
        self.add(p, 4)
        self.client.post(reverse("orders:checkout"), ADDRESS)
        order = Order.objects.get()
        self.client.post(reverse("orders:cancel", args=[order.number]))
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.CANCELLED)
        self.assertEqual(p.stock, 15)

    def test_other_customers_cannot_see_order(self):
        p = make_product()
        self.add(p)
        self.client.post(reverse("orders:checkout"), ADDRESS)
        order = Order.objects.get()
        other = User.objects.create_user("eve", password="pw-123456!")
        self.client.force_login(other)
        self.assertEqual(self.client.get(order.get_absolute_url()).status_code, 403)
        self.assertEqual(self.client.get(reverse("api_track", args=[order.number])).status_code, 403)

    def test_bulk_price_for_verified_pharmacy(self):
        p = make_product(price=1000, bulk_price=800, bulk_min_qty=10)
        buyer = User.objects.create_user("chemist", password="pw-123456!", role=User.Role.PHARMACY,
                                         business_name="Good Health Pharmacy", pcn_premises_number="PCN123")
        self.client.force_login(buyer)
        self.add(p, 10)
        self.client.post(reverse("orders:checkout"), ADDRESS)
        self.assertEqual(Order.objects.get().subtotal, Decimal("8000"))

    def test_staff_can_update_status(self):
        p = make_product()
        self.add(p)
        self.client.post(reverse("orders:checkout"), ADDRESS)
        order = Order.objects.get()
        staff = User.objects.create_user("pharm", password="pw-123456!", role=User.Role.PHARMACIST)
        self.client.force_login(staff)
        self.client.post(reverse("orders:update", args=[order.number]),
                         {"status": "dispatched", "message": "Rider on the way", "rider_name": "Musa", "rider_phone": "0809"})
        order.refresh_from_db()
        self.assertEqual(order.status, "dispatched")
        self.assertEqual(order.updates.count(), 2)
