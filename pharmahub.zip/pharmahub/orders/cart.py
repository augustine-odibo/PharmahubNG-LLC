"""Session-based shopping cart."""
from decimal import Decimal

from django.conf import settings

from catalog.models import Product

SESSION_KEY = "cart"
MAX_QTY = 999


class Cart:
    def __init__(self, request):
        self.request = request
        self.session = request.session
        self.data = self.session.get(SESSION_KEY, {})

    def save(self):
        self.session[SESSION_KEY] = self.data
        self.session.modified = True

    def add(self, product, quantity=1, replace=False):
        key = str(product.pk)
        current = 0 if replace else self.data.get(key, 0)
        qty = max(0, min(MAX_QTY, current + quantity if not replace else quantity))
        if qty == 0:
            self.data.pop(key, None)
        else:
            self.data[key] = qty
        self.save()

    def remove(self, product):
        self.data.pop(str(product.pk), None)
        self.save()

    def clear(self):
        self.data = {}
        self.save()

    def __len__(self):
        return sum(self.data.values())

    def lines(self):
        user = self.request.user
        products = Product.objects.active().filter(pk__in=self.data.keys()).select_related("category")
        out = []
        for p in products:
            qty = self.data[str(p.pk)]
            unit = p.unit_price_for(user, qty)
            out.append({"product": p, "quantity": qty, "unit_price": unit, "line_total": unit * qty})
        # drop products that were deactivated
        stale = set(self.data) - {str(p.pk) for p in products}
        if stale:
            for k in stale:
                self.data.pop(k, None)
            self.save()
        return out

    def products(self):
        return [line["product"] for line in self.lines()]

    @property
    def subtotal(self):
        return sum((line["line_total"] for line in self.lines()), Decimal("0"))

    def delivery_fee(self, fulfilment="delivery"):
        if fulfilment == "pickup" or not self.data:
            return Decimal("0")
        cfg = settings.PHARMAHUB
        return Decimal("0") if self.subtotal >= cfg["FREE_DELIVERY_THRESHOLD"] else Decimal(cfg["DELIVERY_FEE"])

    @property
    def needs_prescription(self):
        return any(p.requires_prescription for p in self.products())
