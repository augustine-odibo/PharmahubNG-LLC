/* PharmaHub front-end behaviour */
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  // ---- mobile menu ----
  const toggle = $("#menuToggle"), links = $("#navLinks");
  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open);
    });
  }

  // ---- promo bar ----
  const promo = $("#promo");
  if (promo) {
    try { if (localStorage.getItem("ph_promo_closed")) promo.style.display = "none"; } catch (e) {}
    const btn = $("#promoClose");
    btn && btn.addEventListener("click", () => {
      promo.style.display = "none";
      try { localStorage.setItem("ph_promo_closed", "1"); } catch (e) {}
    });
  }

  // ---- toast ----
  let toastTimer;
  function toast(text, isError) {
    const t = $("#toast");
    if (!t) return;
    t.textContent = text;
    t.style.background = isError ? "#b42318" : "";
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 2200);
  }

  // ---- add to cart without page reload ----
  document.addEventListener("submit", async (e) => {
    const form = e.target.closest("form[data-ajax-cart]");
    if (!form) return;
    e.preventDefault();
    const btn = form.querySelector("button[type=submit]");
    btn && (btn.disabled = true);
    try {
      const res = await fetch(form.action, {
        method: "POST",
        body: new FormData(form),
        headers: { "X-Requested-With": "XMLHttpRequest", Accept: "application/json" },
        credentials: "same-origin",
      });
      const data = await res.json();
      toast(data.message, !data.ok);
      const count = $("#cartCount");
      if (count && typeof data.count === "number") count.textContent = data.count;
    } catch (err) {
      form.submit(); // fall back to normal post
    } finally {
      btn && (btn.disabled = false);
    }
  });

  // ---- home: product tabs ----
  $$(".tab[data-tab]").forEach((tab) => {
    tab.addEventListener("click", () => {
      $$(".tab[data-tab]").forEach((t) => t.setAttribute("aria-selected", "false"));
      tab.setAttribute("aria-selected", "true");
      $$("[data-panel]").forEach((p) => (p.hidden = p.dataset.panel !== tab.dataset.tab));
    });
  });

  // ---- hero slider ----
  const slides = $$(".slide");
  const dotsWrap = $("#dots");
  if (slides.length > 1 && dotsWrap) {
    let current = 0, timer;
    slides.forEach((_, i) => {
      const d = document.createElement("button");
      d.className = "dot" + (i === 0 ? " active" : "");
      d.type = "button";
      d.setAttribute("aria-label", `Go to slide ${i + 1}`);
      d.addEventListener("click", () => { go(i); restart(); });
      dotsWrap.appendChild(d);
    });
    const dots = [...dotsWrap.children];
    function go(i) {
      slides[current].classList.remove("active"); dots[current].classList.remove("active");
      current = (i + slides.length) % slides.length;
      slides[current].classList.add("active"); dots[current].classList.add("active");
    }
    const restart = () => { clearInterval(timer); timer = setInterval(() => go(current + 1), 6000); };
    $("#prev") && $("#prev").addEventListener("click", () => { go(current - 1); restart(); });
    $("#next") && $("#next").addEventListener("click", () => { go(current + 1); restart(); });
    const hero = $(".hero");
    hero && hero.addEventListener("mouseenter", () => clearInterval(timer));
    hero && hero.addEventListener("mouseleave", restart);
    restart();
  }

  // ---- checkout: hide address fields for pickup ----
  const fulfil = $$("input[name=fulfilment]");
  const addr = $("#delivery-fields");
  if (fulfil.length && addr) {
    const sync = () => { const v = (fulfil.find((r) => r.checked) || {}).value; addr.hidden = v === "pickup"; };
    fulfil.forEach((r) => r.addEventListener("change", sync));
    sync();
  }
})();
