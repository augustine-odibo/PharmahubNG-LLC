from decimal import Decimal, InvalidOperation

from django import template

register = template.Library()


@register.filter
def naira(value):
    """12345.5 -> ₦12,345.50"""
    try:
        return f"₦{Decimal(value):,.2f}"
    except (InvalidOperation, TypeError, ValueError):
        return value


@register.filter
def wa_number(phone):
    """Normalise a Nigerian phone number for wa.me links: 0803... -> 234803..."""
    digits = "".join(ch for ch in str(phone or "") if ch.isdigit())
    if digits.startswith("0"):
        digits = "234" + digits[1:]
    return digits
