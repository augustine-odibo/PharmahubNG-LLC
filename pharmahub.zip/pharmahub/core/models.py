from django.db import models


class Subscriber(models.Model):
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email


class Testimonial(models.Model):
    """Real customer feedback, shown on the homepage only when published.
    Get the customer's permission before publishing."""
    name = models.CharField(max_length=120)
    role = models.CharField(max_length=120, blank=True, help_text="e.g. Pharmacist, Abuja")
    quote = models.TextField()
    rating = models.PositiveSmallIntegerField(default=5)
    is_published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name}: {self.quote[:40]}"
