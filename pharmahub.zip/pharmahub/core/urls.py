from django.urls import path

from . import views

app_name = "core"
urlpatterns = [
    path("", views.home, name="home"),
    path("about-us/", views.about, name="about"),
    path("contact-us/", views.contact, name="contact"),
    path("subscribe/", views.subscribe, name="subscribe"),
    path("staff/", views.staff_dashboard, name="staff_dashboard"),
]
