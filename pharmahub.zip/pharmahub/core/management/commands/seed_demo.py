"""Load demo catalogue data so the site has something to show.

    python manage.py seed_demo

Safe to run more than once. Prices and stock for the demo-only items are
placeholders - edit them in the admin before going live.
"""
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from catalog.models import Category, Product
from inventory.models import Batch, StockMovement, Supplier
from safety.models import DrugInteraction

IMG = "https://pharmahub.com.ng/wp-content/uploads/2026/09/"

PRODUCTS = [
    # name, category, generic, strength, form, schedule, price, sale, image, featured
    ("Imodium", "Digestive health", "loperamide", "2 mg", "capsule", "otc", 45000, 40000, IMG + "imodium-300x300.webp", True),
    ("Probiotic", "Digestive health", "", "", "capsule", "otc", 35000, 30000, IMG + "probiotic-300x300.webp", True),
    ("Cold Compress", "First aid & consumables", "", "", "pack", "consumable", 40000, 35000, IMG + "cold-compress.jpg", True),
    ("Eye Allergy Relief Drop", "Eye care", "", "", "eye drop", "otc", 50000, 30000, IMG + "eye-drop-300x300.webp", True),
    # demo-only items (no images) to show prescriptions + interaction checks
    ("Paracetamol 500 mg Tablets", "Pain relief", "paracetamol", "500 mg", "tablet", "otc", 800, None, "", False),
    ("Aspirin 75 mg Tablets", "Heart health", "aspirin", "75 mg", "tablet", "otc", 1200, None, "", False),
    ("Warfarin 5 mg Tablets", "Heart health", "warfarin", "5 mg", "tablet", "pom", 4500, None, "", False),
    ("Amoxicillin 500 mg Capsules", "Antibiotics", "amoxicillin", "500 mg", "capsule", "pom", 3500, None, "", False),
    ("Oral Rehydration Salts", "Digestive health", "oral rehydration salts", "", "sachet", "otc", 300, None, "", False),
    ("Nitrile Examination Gloves (M)", "First aid & consumables", "", "box of 100", "gloves", "consumable", 9500, 8500, "", False),
]

# Well-established interactions, for demonstration. A pharmacist must review
# every entry against a current reference before relying on it.
INTERACTIONS = [
    ("aspirin", "warfarin", "major",
     "Higher risk of serious bleeding.",
     "Do not take together unless your doctor prescribed both. Speak to a pharmacist.",
     "BNF – verify before go-live"),
    ("glyceryl trinitrate", "sildenafil", "major",
     "Can cause a dangerous drop in blood pressure.",
     "Never combine. Seek medical advice.",
     "BNF – verify before go-live"),
]


class Command(BaseCommand):
    help = "Seed demo categories, products, stock batches and interaction rules."

    @transaction.atomic
    def handle(self, *args, **opts):
        today = timezone.localdate()
        supplier, _ = Supplier.objects.get_or_create(
            name="Demo Pharma Distributors Ltd",
            defaults={"cac_number": "RC-DEMO", "pcn_premises_number": "PCN-DEMO", "is_verified": False},
        )
        created = 0
        for i, (name, cat, generic, strength, form, sched, price, sale, img, feat) in enumerate(PRODUCTS):
            category, _ = Category.objects.get_or_create(name=cat)
            p, new = Product.objects.get_or_create(name=name, defaults={
                "category": category, "generic_name": generic, "strength": strength, "dosage_form": form,
                "schedule": sched, "price": price, "sale_price": sale, "image_url": img, "is_featured": feat,
                "description": f"{name}. Edit this description in the admin.",
                "bulk_price": round(price * 0.85), "bulk_min_qty": 10, "reorder_level": 10,
            })
            if new:
                created += 1
                # two batches: one expiring sooner (sold first, FEFO) and one later
                for n, (months, qty) in enumerate([(4, 15), (18, 40)]):
                    b = Batch.objects.create(
                        product=p, supplier=supplier, batch_number=f"DEMO{i:02d}{n}",
                        expiry_date=today + timedelta(days=30 * months), quantity=qty,
                    )
                    StockMovement.objects.create(product=p, batch=b, change=qty,
                                                 reason=StockMovement.Reason.RECEIVED, reference=b.batch_number)
        for a, b, sev, effect, advice, ref in INTERACTIONS:
            x, y = sorted([a, b])
            DrugInteraction.objects.get_or_create(ingredient_a=x, ingredient_b=y, defaults={
                "severity": sev, "effect": effect, "advice": advice, "reference": ref,
            })
        self.stdout.write(self.style.SUCCESS(f"Seeded {created} new products and {len(INTERACTIONS)} interaction rules."))
