from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse

from accounts.models import User
from catalog.models import Product
from prescriptions.models import Prescription

TMP = "/tmp/pharmahub-test-private"


class PageSmokeTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_demo", verbosity=0)

    def test_public_pages(self):
        p = Product.objects.first()
        for url in ["/", "/shop/", "/shop/?q=para&sort=price_low", p.get_absolute_url(), "/cart/",
                    "/safety/interaction-checker/", "/safety/ask-a-pharmacist/", "/about-us/", "/contact-us/",
                    "/account/login/", "/account/register/", "/api/products/?q=imod", "/robots.txt"]:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200)

    def test_404_page(self):
        self.assertEqual(self.client.get("/shop/does-not-exist/").status_code, 404)

    def test_logged_in_pages(self):
        u = User.objects.create_user("ada", password="pw-123456!")
        self.client.force_login(u)
        for url in ["/account/", "/account/profile/", "/orders/", "/prescriptions/", "/prescriptions/upload/",
                    "/inventory/procurement/"]:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200)

    def test_staff_pages_need_pharmacist(self):
        u = User.objects.create_user("ada", password="pw-123456!")
        self.client.force_login(u)
        for url in ["/staff/", "/inventory/", "/inventory/receive/"]:
            self.assertEqual(self.client.get(url).status_code, 403)
        ph = User.objects.create_user("ph", password="pw-123456!", role=User.Role.PHARMACIST)
        self.client.force_login(ph)
        for url in ["/staff/", "/inventory/", "/inventory/receive/"]:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200)

    def test_register(self):
        r = self.client.post(reverse("accounts:register"), {
            "first_name": "Ngozi", "last_name": "E", "username": "ngozi", "email": "n@example.com",
            "phone": "0803", "role": "customer", "password1": "Very-Strong-Pass-9", "password2": "Very-Strong-Pass-9",
        })
        self.assertRedirects(r, reverse("accounts:dashboard"))

    def test_open_redirect_blocked(self):
        r = self.client.post(reverse("core:subscribe"), {"email": "a@b.com", "next": "//evil.example.com/"})
        self.assertEqual(r["Location"], "/")


@override_settings(PRIVATE_MEDIA_ROOT=TMP)
class PrescriptionPrivacyTests(TestCase):
    def test_only_owner_and_pharmacist_can_view_file(self):
        owner = User.objects.create_user("ada", password="pw-123456!")
        rx = Prescription.objects.create(patient=owner, patient_name="Ada",
                                         file=SimpleUploadedFile("rx.png", b"\x89PNG fake"))
        url = reverse("prescriptions:file", args=[rx.pk])
        self.assertEqual(self.client.get(url).status_code, 302)  # anonymous -> login
        self.client.force_login(User.objects.create_user("eve", password="pw-123456!"))
        self.assertEqual(self.client.get(url).status_code, 403)
        self.client.force_login(owner)
        self.assertEqual(self.client.get(url).status_code, 200)
        self.client.force_login(User.objects.create_user("ph", password="pw-123456!", role=User.Role.PHARMACIST))
        self.assertEqual(self.client.get(url).status_code, 200)

    def test_rejects_bad_file_type(self):
        u = User.objects.create_user("ada", password="pw-123456!")
        self.client.force_login(u)
        r = self.client.post(reverse("prescriptions:upload"), {
            "patient_name": "Ada", "file": SimpleUploadedFile("evil.exe", b"MZ"),
        })
        self.assertContains(r, "Upload a PDF or a photo")
        self.assertFalse(Prescription.objects.exists())
