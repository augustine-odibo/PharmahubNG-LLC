from django.conf import settings


def site(request):
    return {"SITE": settings.PHARMAHUB}
