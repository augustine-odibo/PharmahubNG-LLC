from django.contrib import messages
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.db.models import Count, Sum
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST
from django.utils import timezone

from catalog.models import Product
from inventory.models import ProcurementRequest
from inventory.services import expired_batches, expiring_batches, reorder_report
from orders.models import Order
from prescriptions.models import Prescription
from safety.models import Consultation

from .models import Subscriber, Testimonial
from .permissions import pharmacist_required
from .utils import safe_next


def home(request):
    products = Product.objects.active().prefetch_related("batches")
    featured = list(products.filter(is_featured=True)[:8]) or list(products[:8])
    new_arrivals = list(products.order_by("-created_at")[:8])
    best_ids = (
        Order.objects.exclude(status=Order.Status.CANCELLED)
        .values("items__product").annotate(n=Sum("items__quantity")).order_by("-n")[:8]
    )
    ids = [r["items__product"] for r in best_ids if r["items__product"]]
    best = sorted(products.filter(pk__in=ids), key=lambda p: ids.index(p.pk)) or featured
    return render(request, "core/home.html", {
        "best_sellers": best, "new_arrivals": new_arrivals,
        "testimonials": Testimonial.objects.filter(is_published=True)[:3],
    })


@require_POST
def subscribe(request):
    email = request.POST.get("email", "").strip().lower()
    try:
        validate_email(email)
    except ValidationError:
        messages.error(request, "Please enter a valid email address.")
    else:
        Subscriber.objects.get_or_create(email=email)
        messages.success(request, "Thanks for subscribing! 🎉")
    return redirect(safe_next(request, request.POST.get("next"), "/"))


def about(request):
    return render(request, "core/about.html")


def contact(request):
    return render(request, "core/contact.html")


@pharmacist_required
def staff_dashboard(request):
    today = timezone.localdate()
    active_products = Product.objects.active()
    ctx = {
        "pending_rx": Prescription.objects.filter(status=Prescription.Status.PENDING).select_related("patient")[:20],
        "open_consults": Consultation.objects.filter(status=Consultation.Status.OPEN)[:20],
        "awaiting_rx_orders": Order.objects.filter(status=Order.Status.AWAITING_RX)[:20],
        "active_orders": Order.objects.filter(status__in=Order.ACTIVE_STATUSES).exclude(status=Order.Status.AWAITING_RX)[:20],
        "procurement": ProcurementRequest.objects.exclude(
            status__in=[ProcurementRequest.Status.FULFILLED, ProcurementRequest.Status.DECLINED]
        )[:10],
        "expiring": expiring_batches()[:15],
        "expired": expired_batches()[:15],
        "reorder": reorder_report(active_products)[:15],
        "stats": {
            "orders_today": Order.objects.filter(created_at__date=today).count(),
            "revenue_today": Order.objects.filter(created_at__date=today).exclude(status=Order.Status.CANCELLED)
            .aggregate(t=Sum("total"))["t"] or 0,
            "pending_rx": Prescription.objects.filter(status=Prescription.Status.PENDING).count(),
            "open_consults": Consultation.objects.filter(status=Consultation.Status.OPEN).count(),
            "urgent_consults": Consultation.objects.filter(
                status=Consultation.Status.OPEN, topic=Consultation.Topic.POISON
            ).count(),
        },
        "status_counts": Order.objects.values("status").annotate(n=Count("id")),
    }
    return render(request, "core/staff_dashboard.html", ctx)


def handler404(request, exception):
    return render(request, "404.html", status=404)
