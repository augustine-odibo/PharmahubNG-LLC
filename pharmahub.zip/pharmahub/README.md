# PharmaHub – Nigeria's digital pharmacy platform

A Django web app for [pharmahub.com.ng](https://pharmahub.com.ng): an e-pharmacy, medicine supply chain and medication-safety service, all in one.

**For patients:** shop genuine medicines, upload prescriptions, check drug interactions, ask a pharmacist for free, and track deliveries.
**For pharmacists (staff):** review prescriptions, answer consultations, manage orders and riders, and run inventory.
**For pharmacies & hospitals (B2B):** bulk pricing and procurement requests.

---

## Features

| Area | What it does |
|---|---|
| **Shop** | Categories, search by brand or generic name, filters, sale prices, product pages with NAFDAC no., strength, warnings |
| **Prescriptions** | Patients upload a PDF or photo → a pharmacist approves or rejects it. Prescription-only (POM) items can't ship until approved. Files are stored **privately** and only viewable by the patient and pharmacists |
| **Orders & delivery** | Session cart, checkout (delivery or pickup, all 36 states + FCT), WhatsApp order confirmation, live tracking timeline, rider details, customer cancellation |
| **Inventory (supply chain)** | Stock tracked **per batch and expiry date**. Sales use **FEFO** (first-expiry-first-out). Expired stock is **never sold**. Full audit trail of stock movements |
| **Smart reordering** | Reorder suggestions from real sales velocity × supplier lead time + safety stock, with "days of stock left" |
| **Expiry alerts** | Dashboard and daily report (`stock_alerts`) for batches expiring soon and expired stock on the shelf |
| **Drug safety** | Interaction checker (by name or shop product), **automatic interaction warnings in the cart and at checkout**, Ask-a-Pharmacist with priority flag for poisoning queries |
| **B2B** | Verified pharmacies (with PCN premises no.) get bulk pricing automatically; procurement request → quote workflow; supplier registry with CAC/PCN verification |
| **Staff dashboard** | One screen: today's orders & revenue, prescription queue, consultations, stock alerts, procurement |
| **JSON API** | `/api/products/?q=`, `/api/interactions/?drugs=a,b`, `/api/orders/<number>/` – ready for a future mobile app |
| **Security** | Role-based access, CSRF, private prescription storage, upload validation, open-redirect protection, HSTS/secure cookies in production, passes `check --deploy` |

## Quick start (local)

```bash
git clone https://github.com/<you>/<repo>.git
cd <repo>
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # Windows: copy .env.example .env
python manage.py migrate
python manage.py seed_demo                             # demo products, stock and interaction rules
python manage.py createsuperuser                       # your admin login
python manage.py runserver
```

Open http://127.0.0.1:8000 – the admin is at http://127.0.0.1:8000/admin/.

To make someone a pharmacist: in the admin, open **Users**, set **Role = Pharmacist (staff)** (or tick *Staff status*). They then see the **Staff** link in the menu.

## Running tests

```bash
python manage.py test
```

GitHub Actions runs the tests and Django's production security check on every push (`.github/workflows/ci.yml`).

## Deploying

### Render (recommended, easiest)
1. Push this repo to GitHub.
2. On [render.com](https://render.com): **New + → Blueprint** → pick the repo. `render.yaml` creates the web service and a Postgres database.
3. After the first deploy, open the Render **Shell** and run `python manage.py createsuperuser`.
4. Point `pharmahub.com.ng` at Render (Settings → Custom Domains).

Uploaded files (product images, prescriptions) need persistent storage. `render.yaml` attaches a disk at `/var/data`, which needs a paid Render plan. Alternatively, use product `image_url`s and add cloud storage (e.g. S3 / Cloudflare R2 via `django-storages`).

### Any other host (VPS, Railway, Heroku-style)
Set the environment variables from `.env.example` with `DEBUG=False`, a long random `SECRET_KEY`, your `ALLOWED_HOSTS`, `CSRF_TRUSTED_ORIGINS` and `DATABASE_URL`, then:

```bash
pip install -r requirements.txt
python manage.py collectstatic --noinput
python manage.py migrate
gunicorn config.wsgi
```

### Daily stock report
Schedule this once a day (Render Cron Job, cron, etc.):

```bash
python manage.py stock_alerts --email ops@pharmahub.com.ng
```

## Before you go live – checklist

- [ ] **Interaction rules:** the two seeded rules are demonstrations. A licensed pharmacist must add and review rules from a current reference (BNF, Stockley's, SmPC) in **Admin → Drug interactions**.
- [ ] Replace demo products, prices and stock (`seed_demo` items are placeholders), and fill in NAFDAC numbers.
- [ ] Verify suppliers' CAC and PCN documents before ticking **Verified**.
- [ ] Add real testimonials (with customers' permission) in **Admin → Testimonials**.
- [ ] Set up SMTP email so password resets and stock reports send.
- [ ] Review your privacy policy for handling prescriptions and health data under the Nigeria Data Protection Act (NDPA) 2023.

## Project layout

```
config/          settings, URLs
core/            home, about, contact, staff dashboard, newsletter, testimonials
accounts/        custom user with roles (patient, pharmacy, pharmacist, supplier)
catalog/         categories and products
inventory/       suppliers, batches, stock movements, FEFO + reorder logic, B2B procurement
prescriptions/   private uploads + pharmacist review
orders/          cart, checkout, orders, delivery tracking
safety/          interaction checker, ask-a-pharmacist
templates/       HTML (based on the PharmaHub homepage design)
static/          CSS, JS, images
static_site/     the original standalone homepage (index.html)
```

## Payments

Orders are confirmed on WhatsApp for now (bank transfer / POS on delivery). To add Paystack or Flutterwave later, hook into `orders/services.py → place_order()` and mark orders **Confirmed** from the payment webhook.

## Roadmap ideas

- Paystack / Flutterwave checkout
- SMS/WhatsApp Business API notifications on status changes
- Refill reminders for chronic medicines
- Supplier portal (suppliers manage their own price lists)
- NAFDAC Mobile Authentication Service (MAS) scratch-code check
- Mobile app using the JSON API

---
© PharmaHub · FCT, Abuja · info@pharmahub.com.ng
