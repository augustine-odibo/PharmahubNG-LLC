from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from core.utils import safe_next

from .forms import ProfileForm, RegisterForm


def register(request):
    if request.user.is_authenticated:
        return redirect("accounts:dashboard")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Welcome to PharmaHub! Your account is ready.")
        return redirect(safe_next(request, request.GET.get("next"), "accounts:dashboard"))
    return render(request, "accounts/register.html", {"form": form})


@login_required
def dashboard(request):
    user = request.user
    ctx = {
        "orders": user.orders.prefetch_related("items")[:10],
        "prescriptions": user.prescriptions.all()[:10],
        "consultations": user.consultations.all()[:10],
        "procurement": user.procurement_requests.all()[:10],
    }
    return render(request, "accounts/dashboard.html", ctx)


@login_required
def profile(request):
    form = ProfileForm(request.POST or None, instance=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Profile updated.")
        return redirect("accounts:dashboard")
    return render(request, "accounts/profile.html", {"form": form})
