from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import User


class RegisterForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=[(User.Role.CUSTOMER, "Patient / customer"), (User.Role.PHARMACY, "Pharmacy, hospital or clinic (bulk buyer)")],
        initial=User.Role.CUSTOMER, widget=forms.RadioSelect,
    )

    class Meta:
        model = User
        fields = ["first_name", "last_name", "username", "email", "phone", "role", "business_name", "pcn_premises_number"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["email"].required = True
        self.fields["first_name"].required = True
        self.fields["phone"].required = True

    def clean(self):
        data = super().clean()
        if data.get("role") == User.Role.PHARMACY and not data.get("business_name"):
            self.add_error("business_name", "Enter your pharmacy, hospital or clinic name.")
        return data


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["first_name", "last_name", "email", "phone", "address", "city", "state", "business_name", "pcn_premises_number"]
        widgets = {"address": forms.Textarea(attrs={"rows": 2})}
