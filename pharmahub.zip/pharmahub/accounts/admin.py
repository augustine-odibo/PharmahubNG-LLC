from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class PharmaUserAdmin(UserAdmin):
    list_display = ["username", "get_full_name", "email", "phone", "role", "business_name", "is_staff"]
    list_filter = ["role", "is_staff", "is_active"]
    search_fields = ["username", "first_name", "last_name", "email", "phone", "business_name"]
    fieldsets = UserAdmin.fieldsets + (
        ("PharmaHub", {"fields": ("role", "phone", "address", "city", "state",
                                  "business_name", "pcn_premises_number", "pcn_licence_number")}),
    )
