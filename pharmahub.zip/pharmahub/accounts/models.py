from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        CUSTOMER = "customer", "Patient / Customer"
        PHARMACY = "pharmacy", "Pharmacy / Hospital (B2B buyer)"
        PHARMACIST = "pharmacist", "Pharmacist (staff)"
        SUPPLIER = "supplier", "Supplier / Vendor"

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.CUSTOMER)
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=80, blank=True)
    state = models.CharField(max_length=80, blank=True)
    # B2B buyers
    business_name = models.CharField(max_length=150, blank=True)
    pcn_premises_number = models.CharField(
        "PCN premises licence no.", max_length=50, blank=True,
        help_text="Required to buy prescription-only medicines in bulk.",
    )
    # Pharmacist staff
    pcn_licence_number = models.CharField("PCN practising licence no.", max_length=50, blank=True)

    @property
    def is_pharmacist(self):
        return self.is_superuser or self.is_staff or self.role == self.Role.PHARMACIST

    @property
    def is_b2b(self):
        return self.role == self.Role.PHARMACY

    def __str__(self):
        return self.get_full_name() or self.username
