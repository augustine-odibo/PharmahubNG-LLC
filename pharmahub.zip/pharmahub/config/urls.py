from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from django.views.generic import TemplateView

from catalog.views import api_products
from orders.views import api_track
from safety.views import api_interactions

admin.site.site_header = "PharmaHub Admin"
admin.site.site_title = "PharmaHub"
admin.site.index_title = "Pharmacy operations"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("core.urls")),
    path("account/", include("accounts.urls")),
    path("shop/", include("catalog.urls")),
    path("", include("orders.urls")),
    path("prescriptions/", include("prescriptions.urls")),
    path("safety/", include("safety.urls")),
    path("inventory/", include("inventory.urls")),
    # JSON API
    path("api/products/", api_products, name="api_products"),
    path("api/interactions/", api_interactions, name="api_interactions"),
    path("api/orders/<str:number>/", api_track, name="api_track"),
    path("robots.txt", TemplateView.as_view(template_name="robots.txt", content_type="text/plain")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

handler404 = "core.views.handler404"
